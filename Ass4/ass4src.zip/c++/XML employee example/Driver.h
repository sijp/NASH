#include <vector>	
#include "PocoXMLParser.h"
#include <iostream>


void printData(std::vector<Employee*> employees);
